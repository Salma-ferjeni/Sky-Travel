#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include "reservation.h"
sejour s;
hotel h;
void
on_ajouter_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*input4,*input5;
GtkWidget *Jour,*Mois , *Annee;
GtkWidget *duree;
GtkWidget *Combobox1;
sejour s;
input1=lookup_widget(obj,"promo");
input2=lookup_widget(obj,"chambre1");
input3=lookup_widget(obj,"chambre2");
input4=lookup_widget(obj,"demi");
input5=lookup_widget(obj,"complete");
Jour = lookup_widget(obj,"jour");
Mois = lookup_widget(obj,"mois");
Annee = lookup_widget(obj,"annee");
duree=lookup_widget(obj,"duree");
Combobox1=lookup_widget(obj,"combobox1");
strcpy (s.promotion,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(s.tar.chambre_single,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(s.tar.chambre_double,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(s.tar.demi_pension,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(s.tar.pension_complete,gtk_entry_get_text(GTK_ENTRY(input5)));
s.date_arrivee.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
s.date_arrivee.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
s.date_arrivee.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));
//combobox1
strcpy(s.h.nom_hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));

g_print("ajout_sejour worked");
ajout("ajout_sejour1",&s);


}


void
on_afficher_clicked                    (GtkWidget      *obj,
                                        gpointer         user_data)
{

GtkWidget *fenetre_afficher1;
GtkWidget *treeview1;
  
  
  fenetre_afficher1=lookup_widget(obj,"fenetre_afficher");
  fenetre_afficher1=create_fenetre_afficher();
   
treeview1=lookup_widget(fenetre_afficher1,"treeview1");
gtk_widget_show(fenetre_afficher1);
afficher_sejour(treeview1);
}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{

}
/*
hotel h;
date date_arrivee;
int duree;
char promotion[20];
tarif tar;
HOTEL,
DATE,
DUREE,
PROMOTION,
TARIF1,
TARIF2,
TARIF3,
TARIF4,
*/

void
on_treeview1_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeModel *model;
gchar *str_data,*str_data1,*str_data2,*str_data3,*str_data4,*str_data5;
GtkListStore *list_store;
//list_store=gtk_tree_view_get_model(GTK_TREE_VIEW(view));
//supprimer1(s1.h.nom_hotel);

GtkTreeIter iter;
//g_print("This trip has been deleted");
list_store=gtk_tree_view_get_model(view);
/*
*/
//if (!gtk_tree_model_get_iter(model,&iter,path))
//g_print("no deleted");
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter,path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data1, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data2, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 5, &str_data3, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 6, &str_data4, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 7, &str_data5, -1);
 

     
  }

strcpy(s.h.nom_hotel,str_data);
strcpy(s.tar.chambre_single,str_data1);
strcpy(s.tar.chambre_double,str_data2);
strcpy(s.promotion,str_data3);
strcpy(s.tar.pension_complete,str_data4);
strcpy(s.tar.demi_pension,str_data5);
//int j,m,a;
//sscanf(str_data1,"%d %d %d",&s1.date_arrivee.jour,&s1.date_arrivee.mois,&s1.date_arrivee.annee);
//sscanf(str_data2,"%d",&s1.duree);
//gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//*
g_print(h.nom_hotel);
}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
supprimer1((char*)s.h.nom_hotel);
//GtkListStore *list_store;/                      
//GtkWidget *treeview1;/


//supprimer(h.num_responsable);
GtkWidget *fenetre_afficher=lookup_widget(GTK_WIDGET(button),"fenetre_afficher");
treeview1=lookup_widget(fenetre_afficher,"treeview1");
//
afficher_sejour(treeview1);
gtk_widget_show(treeview1);

}


void
on_ajouter2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fen_log,*fen2 ;
fen_log = lookup_widget(objet,"fenetre_ajout");
fen2 = lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fen2);
fen_log = create_fenetre_ajout();
gtk_widget_show(fen_log);

}
/*

date date_arrivee;
int duree;
char promotion[20];
tarif tar;
hotel h
*/
sejour z ;
void
on_modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *hot,*promotion,*tarif1,*tarif2,*tarif3,*tarif4;
supprimer1((char*)s.h.nom_hotel);

/*****Na3mlo Actualiser lil liste **************/
GtkWidget *fenetre_afficher=lookup_widget(button,"fenetre_afficher");
GtkWidget *fenetre_ajout=lookup_widget(button,"fenetre_ajout");
gtk_widget_hide(fenetre_afficher);
fenetre_ajout=create_fenetre_ajout();
gtk_widget_show(fenetre_ajout);





promotion=lookup_widget(fenetre_ajout,"promo");
gtk_entry_set_text(GTK_ENTRY(promotion),s.promotion);


tarif1=lookup_widget(fenetre_ajout,"chambre1");
gtk_entry_set_text(GTK_ENTRY(tarif1),s.tar.chambre_single);

tarif2=lookup_widget(fenetre_ajout,"chambre2");
gtk_entry_set_text(GTK_ENTRY(tarif2),s.tar.chambre_double);

tarif3=lookup_widget(fenetre_ajout,"demi");
gtk_entry_set_text(GTK_ENTRY(tarif3),s.tar.demi_pension);

tarif4=lookup_widget(fenetre_ajout,"complete");
gtk_entry_set_text(GTK_ENTRY(tarif4),s.tar.pension_complete);
}

