#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);
