#include "reservation.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>
enum
{
HOTEL,
DATE,
DUREE,
PROMOTION,
TARIF1,
TARIF2,
TARIF3,
TARIF4,
COLUMNS,
};
void ajout (char ajout_sejour[], sejour *s)
{
FILE *f;
f=fopen("ajout_sejour","ab+");
if (!f)exit(-1);

fwrite(s,sizeof(sejour),1,f);
fclose(f);
}

void afficher_sejour(GtkWidget *show)
{
      sejour s;
      GtkCellRenderer *render ;
      GtkTreeViewColumn *column;
      GtkTreeIter miter;
      GtkListStore *store ;
     
     
       store = NULL;
      
     int jour,mois,annee;
     char date1[1024];
     
      //FILE *f ;
      store =gtk_tree_view_get_model(GTK_TREE_VIEW(show));
      if(!store){
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("hotel",render,"text",HOTEL,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("date",render,"text",DATE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("duree",render,"text",DUREE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
            column = gtk_tree_view_column_new_with_attributes("promotion",render,"text",PROMOTION,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("tarif chambre single",render,"text",TARIF1,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("tarif chambre double",render,"text",TARIF2,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
	   render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("tarif demi pension",render,"text",TARIF3,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("tarif pension complete",render,"text",TARIF4,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
      }
      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

FILE *f = fopen("ajout_sejour","rb") ;
      if(!f) exit(-1);

      while(fread(&s,sizeof(sejour),1,f)==1)
      {
          gtk_list_store_append(store,&miter);
          sprintf(date1,"%d %d %d",s.date_arrivee.jour,s.date_arrivee.mois,s.date_arrivee.annee);
          
          gtk_list_store_set(store,&miter,HOTEL,s.h.nom_hotel,DATE,date1,DUREE,s.duree,PROMOTION,s.promotion,TARIF1,s.tar.chambre_single,TARIF2,s.tar.chambre_double,TARIF3,s.tar.demi_pension,TARIF4,s.tar.pension_complete,-1);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(show),GTK_TREE_MODEL(store));
      g_object_unref(store);

}
void supprimer(char *nomb)
{
 
 FILE *f=fopen("ajout_sejour1","rb");
FILE *f1=fopen("rem_sejour","ab+");
sejour s;

int r = 1;
while(fread(&s,sizeof(sejour),1,f))
   {
      if(strcmp(nomb,s.promotion)!=0)
        {
               fwrite(&s,sizeof(sejour),1,f1);

         }

   }
fclose(f);
 fclose(f1);
sejour s1;
f=fopen("sejour1","wb");
f1=fopen("sejour_test","rb");
while(fread(&s1,sizeof(sejour),1,f1))
 {
   fwrite(&s1,sizeof(sejour) , 1, f);

  }
  fclose(f1);
   fclose(f);
  return r;



}//*
void supprimer1 (char *promotion)
{
sejour s1;
FILE *old;
FILE *new_=NULL;

new_=fopen("rem_sejour","wb");
fclose(new_);

old=fopen("ajout_sejour","rb");
new_=fopen("rem_sejour","ab");

int i=0;
while(!(feof(old)))
       {i++;
        fread(&s1,1,sizeof(sejour),old);
       }
fclose(old);
old=fopen("ajout_sejour","rb");

int j=0;
while(j<i-1)
      {j++;
       fread(&s1,1,sizeof(sejour),old);

       if(strcmp(s1.h.nom_hotel,promotion))
             {
g_print("hhh");
             fwrite(&s1,sizeof(sejour),1,new_);
             }
      }
fclose(new_);
fclose(old);
remove("ajout_sejour");
rename("rem_sejour","ajout_sejour");
}
void modifier(sejour z,sejour b)
{
sejour a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("rem_sejour","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("ajout_sejour1","rb");
new=fopen("rem_sejour","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&a,1,sizeof(sejour),old);
	}
fclose(old);
old=fopen("ajout_sejour1","rb");
/******************************/
int j=0;
while(j<i)
	{j++;
	fread(&a,1,sizeof(sejour),old);
	
	if(strcmp(a.h.nom_hotel,z.h.nom_hotel)!=0)
		{	
		fwrite(&a,sizeof(sejour),1,new);
		}
        else  if(strcmp(a.h.nom_hotel,z.h.nom_hotel)==0)  
                {
                fread(&b,1,sizeof(sejour),new);
                
                }
               
	}
fclose(new);
fclose(old);
remove("ajout_sejour1");//nfas5ou il fichier li9dim
rename("rem_sejour","ajout_sejour1");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
//return b;

/*****Na3mlo Actualiser lil liste **************/

}




