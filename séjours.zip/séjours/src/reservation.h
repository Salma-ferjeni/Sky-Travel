#include <gtk/gtk.h>
typedef struct date
{
int jour;
int mois;
int annee;
} date;
typedef struct hotel
{
char nom_hotel[20];
char adresse[20];
int  etoile;
char num_responsable[20];
}hotel;
typedef struct tarif
{
char economique[20];
char business_class[20];
char chambre_single[10];
char chambre_double[10];
char demi_pension[10];
char pension_complete[10];
}tarif;
typedef struct sejour_hotellier
{
hotel h;
date date_arrivee;
int duree;
char promotion[20];
tarif tar;
}sejour;
void ajout (char ajout_sejour[], sejour *s);
void afficher_sejour(GtkWidget *show);
void supprimer(char *nomb);
void supprimer1 (char *promotion);
void modifier(sejour z,sejour b);
